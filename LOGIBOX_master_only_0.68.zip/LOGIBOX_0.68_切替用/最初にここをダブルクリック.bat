@echo off
setlocal
cd /d "%~dp0"
set "LOGIBOX_RUNTIME=py"
py -c "import sys; sys.exit(sys.version_info < (3,10))" >nul 2>nul
if not errorlevel 1 goto run
set "LOGIBOX_RUNTIME=python"
python -c "import sys; sys.exit(sys.version_info < (3,10))" >nul 2>nul
if errorlevel 1 goto error
:run
%LOGIBOX_RUNTIME% "%~dp0master_only_setup.py"
if errorlevel 1 pause
goto :eof
:error
echo Python 3.10+ is required. Please install Python and try again.
pause
