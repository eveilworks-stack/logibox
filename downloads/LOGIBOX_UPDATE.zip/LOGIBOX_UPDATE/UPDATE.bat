@echo off
setlocal
call "%~dp0logibox\update.bat"
exit /b %errorlevel%
