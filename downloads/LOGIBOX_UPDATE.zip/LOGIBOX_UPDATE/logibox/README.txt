LOGIBOX ver.0.67 ローカル起動・更新判定修正版（内部番号0.6.7 / schema12）
既存データを保持する更新専用パッケージです。

1. アプリが起動できない場合もdataを消さないでください。
   新版ZIPは既存のLOGIBOXと別の場所へ全て展開します。
   既存フォルダへZIPを直接上書き展開しないでください。
2. 旧LOGIBOXがOneDrive内にある場合は、エクスプローラーで旧フォルダを
   「このデバイス上で常に保持する」にし、ダウンロード完了を待ちます。
   OneDriveの同期を一時停止し、他PCからも同じデータを開かないでください。
   旧フォルダを移動・複製して起動先を変える必要はありません。
3. LOGIBOXの全てのウィンドウを閉じます。ブラウザだけを閉じてもサーバーは残ります。
   再起動済みなら、LOGIBOXを再度開かずそのまま更新できます。
   python.exe等を一括で強制終了したり、ロックファイルを削除したりしないでください。
4. 新しく展開したlogibox内のupdate.batを開きます（Python3.10以降）。
   1つ目の選択画面：利用中の旧logiboxフォルダを指定します。
   dataフォルダそのものではなく、data/app.dbを含む親フォルダです。
   2つ目の選択画面：バックアップ保存先を指定します。
   OneDrive外の既存ローカルフォルダ（例 C:\LOGIBOX_Backups）を推奨します。
   外部にPDF保存先を指定している場合、その保存先は別途保管してください。
5. 更新ツールは配布物照合→ポート排他確保とデータロック→全体バックアップ→
   バックアップのCRC・全ファイルSHA256・ファイル一覧照合→コード更新の順に実行します。
   バックアップは選択先のLOGIBOX-before-0.6.7-*/full-installation.zipです。
   バックアップに失敗した場合はコードを更新しません。
   案件・入金・会社情報・ログイン設定・社印・PDFを含むdataは更新対象外です。
   既存PDF・既存document_templatesも置換しません。
   既存ロックは削除・書き換えません。ロック中のファイルはZIPから除外します。
6. 更新完了後は必ず「更新された旧フォルダ」の起動.vbsを開いてください。
   新しいZIPの展開先からは起動しません。
   デスクトップのLOGIBOXリンクもこの旧フォルダを向くように更新されます。
7. 従来のパスワードでログインし、会社情報、案件、入金、社印、PDFを確認します。
   表示バージョンは0.67のままです。コードのビルド識別値で修正版を区別します。
   確認後にOneDrive同期を再開してください。

失敗したとき
・原因確認までロックを削除しないでください。強制続行する機能はありません。
・エラー画面に出る診断ログを確認します。
  通常：実行したlogibox\diagnostics\runtime.log
  書き込み不可時：%TEMP%\LOGIBOX-diagnostics\runtime.log
  PowerShell起動前後：logibox\diagnostics\bootstrap.log
  その代替：%TEMP%\LOGIBOX-bootstrap.log
  VBSがPowerShellを呼べない場合：%TEMP%\LOGIBOX-vbs.log（UTF-16）
  サーバー起動後：従来どおりdata\launcher.log
  runtime.logは時刻、処理段階、例外型、errno、winerror、例外の連鎖を記録します。
・8766使用中またはWindowsで予約・制限されている場合は更新を中止します。
  通信失敗だけで「アプリ実行中」「ネットワーク制限」と断定しません。
・APP_DATA指定時は取り違え防止のため中止します。環境変数を安易に削除せず、
  実データ保存先と全体バックアップを確認してください。
・OneDriveの未ダウンロードファイル、リンク、読込権限、容量不足、
  同期中のファイル変化でバックアップできない場合も中止します。
・コード書き換え途中で失敗した場合は起動せず、表示されたZIPを保管してください。
  バックアップ全体を別フォルダに展開して復旧します。
  既存dataへ古いDBを上書きしたり、元の案件リセット版のDBをコピーしないでください。

CLI（新版のlogiboxで実行）
  py update.py --target "C:\Users\利用者\OneDrive\旧 LOGIBOX\logibox" --backup-dir "C:\LOGIBOX_Backups"
  update.bat --target "C:\Users\利用者\OneDrive\旧 LOGIBOX\logibox" --backup-dir "C:\LOGIBOX_Backups"

Windowsでの隔離テスト（既存運用DBは使用しません）
  新版logibox内で py -m unittest test_runtime_check test_release_update test_password_recovery test_windows_runtime -v
  一時フォルダにテスト専用DBを作り、更新バッチ、Windows mutex、実サーバー起動・再利用を検証します。
  テストが起動した子プロセスだけを終了します。8766が既に使用中なら実行しないでください。
  GUIの起動.vbs・フォルダ選択・ショートカット操作は上記手順で別途確認してください。
  この配布物を作成した環境はLinuxです。Windows実機テスト済みという扱いにはしていません。
