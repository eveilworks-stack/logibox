"""No user data or live Windows installation is used by these tests."""
import errno
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import json
import os
from pathlib import Path
import socket
import tempfile
import threading
import unittest
from unittest.mock import patch

import app_version
from auth_security import data_lock
import launcher
import runtime_check as check


class RuntimeCheckTests(unittest.TestCase):
    def test_unused_port_is_available_without_http(self):
        with socket.socket() as available:
            available.bind(('127.0.0.1', 0))
            port = available.getsockname()[1]
        with patch.object(check, 'PORT', port), patch('launcher.open_local', side_effect=AssertionError('HTTP should not run')):
            self.assertFalse(launcher.ready())

    def test_exclusive_reservation_blocks_other_binds(self):
        with patch.object(check, 'PORT', 0):
            # A real listener verifies the same check on both Windows and Linux.
            with socket.socket() as listener:
                listener.bind(('127.0.0.1', 0)); listener.listen()
                with patch.object(check, 'PORT', listener.getsockname()[1]):
                    self.assertFalse(check.port_available())
                    with self.assertRaises(RuntimeError):
                        with check.reserve_port(): pass

    def test_http_ignores_broken_proxy_and_preserves_identity_check(self):
        class Handler(BaseHTTPRequestHandler):
            def do_GET(self):
                self.send_response(200); self.end_headers()
                self.wfile.write(json.dumps(app_version.runtime_identity()).encode())
            def log_message(self, *args): pass
        server = ThreadingHTTPServer(('127.0.0.1', 0), Handler)
        worker = threading.Thread(target=server.serve_forever, daemon=True); worker.start()
        try:
            port = server.server_address[1]
            with patch.dict(os.environ, {'HTTP_PROXY': 'http://127.0.0.1:1', 'http_proxy': 'http://127.0.0.1:1', 'NO_PROXY': '', 'no_proxy': ''}), patch.object(check, 'PORT', port), patch.object(launcher, 'URL', f'http://127.0.0.1:{port}/'):
                self.assertTrue(launcher.ready())
        finally:
            server.shutdown(); server.server_close(); worker.join()

    def test_unknown_bind_failure_aborts_and_logs_cause(self):
        error = OSError(errno.EIO, 'socket inspection failed')
        with tempfile.TemporaryDirectory() as tmp, patch.object(check, '__file__', str(Path(tmp) / 'runtime_check.py')), patch.object(check.socket, 'socket') as factory:
            factory.return_value.__enter__.return_value.bind.side_effect = error
            with self.assertRaises(RuntimeError): check.port_available()
            entry = json.loads((Path(tmp) / 'diagnostics/runtime.log').read_text())
            self.assertEqual(entry['errno'], errno.EIO)
            self.assertIn('socket inspection failed', entry['traceback'])

    def test_windows_access_denied_is_not_mistaken_for_stopped(self):
        error = OSError(errno.EACCES, 'Windows exclusive bind or policy')
        error.winerror = 10013
        with patch.object(check.socket, 'socket') as factory:
            factory.return_value.__enter__.return_value.bind.side_effect = error
            self.assertFalse(check.port_available())
            with self.assertRaises(RuntimeError):
                with check.reserve_port(): pass

    def test_existing_empty_and_nonempty_locks_are_never_written_or_removed(self):
        with tempfile.TemporaryDirectory() as tmp:
            lock = Path(tmp) / '.logibox-auth.lock'
            for content in (b'', b'original-lock-data'):
                lock.write_bytes(content)
                with data_lock(tmp): pass
                self.assertEqual(lock.read_bytes(), content)


if __name__ == '__main__': unittest.main()
