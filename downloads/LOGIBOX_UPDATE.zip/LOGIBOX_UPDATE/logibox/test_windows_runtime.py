"""Native Windows smoke test: isolated fixture only; never selects a user's DB."""
import hashlib
import os
from pathlib import Path
import shutil
import sqlite3
import subprocess
import sys
import tempfile
import unittest

import update


@unittest.skipUnless(os.name == 'nt', 'Requires native Windows mutex, WinSock and cmd.exe')
class WindowsSmokeTests(unittest.TestCase):
    def test_batch_update_and_launcher_with_existing_database(self):
        with tempfile.TemporaryDirectory(prefix='LOGIBOX-Windows-test-') as tmp:
            root = Path(tmp)
            source = root / 'new'
            shutil.copytree(update.SOURCE, source, ignore=shutil.ignore_patterns('data', 'diagnostics', '__pycache__'))
            target = root / 'OneDrive - テスト会社' / '旧 LOGIBOX'
            target.mkdir(parents=True)
            shutil.copytree(source, target, dirs_exist_ok=True)
            env = dict(os.environ); env.pop('APP_DATA', None)
            # Only this newly created temporary installation is initialized.
            subprocess.run([sys.executable, '-c', 'import server; server.init()'], cwd=target, env=env, check=True)
            db = target / 'data/app.db'
            before = hashlib.sha256(db.read_bytes()).hexdigest()
            with sqlite3.connect(db) as connection:
                before_sql = '\n'.join(connection.iterdump())
            backup = root / 'backups'; backup.mkdir()
            result = subprocess.run(['cmd.exe', '/d', '/c', str(source / 'update.bat'), '--target', str(target), '--backup-dir', str(backup)],
                                    cwd=source, env=env, stdin=subprocess.DEVNULL, capture_output=True, timeout=90)
            self.assertEqual(result.returncode, 0, result.stdout.decode('utf-8', errors='replace') + result.stderr.decode('utf-8', errors='replace'))
            self.assertEqual(before, hashlib.sha256(db.read_bytes()).hexdigest())
            # Invoke the real Windows launcher/mutex, track only its own child.
            code = '''import launcher, subprocess
children = []
original = subprocess.Popen
def tracked(*args, **kwargs):
    child = original(*args, **kwargs)
    children.append(child)
    return child
launcher.subprocess.Popen = tracked
launcher.webbrowser.open = lambda url: True
try:
    launcher.main()
    assert launcher.ready()
    launcher.main()  # reuse existing identical process
    assert len(children) == 1
finally:
    for child in children:
        child.terminate()
        child.wait(timeout=15)
'''
            subprocess.run([sys.executable, '-c', code], cwd=target, env=env, check=True, timeout=100)
            with sqlite3.connect(db) as connection:
                self.assertEqual(before_sql, '\n'.join(connection.iterdump()))
            # Parse the PowerShell entry point using the actual Windows parser.
            command = "$errors=$null; [System.Management.Automation.Language.Parser]::ParseFile($args[0],[ref]$null,[ref]$errors) | Out-Null; if ($errors.Count) { $errors | Out-String | Write-Error; exit 1 }"
            parser = root / 'parse.ps1'; parser.write_text(command, encoding='utf-8-sig')
            subprocess.run(['powershell.exe', '-NoProfile', '-File', str(parser), str(target / 'launch.ps1')], check=True, timeout=30)


if __name__ == '__main__': unittest.main()
