"""Data-preserving in-place update. Run using the NEW distribution's Python."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import tempfile
import zipfile

from auth_security import data_lock
from app_version import VERSION
from runtime_check import reserve_port, diagnostic
from build_release import APPLICATION, ASSETS

SOURCE = Path(__file__).resolve().parent


def verified_files(source):
    manifest = json.loads((source / 'SOURCE_MANIFEST.json').read_text(encoding='utf-8-sig'))
    if manifest['version'] != VERSION:
        raise RuntimeError('配布物のバージョンが一致しません。')
    result = []
    for name, expected in manifest['sha256'].items():
        rel = Path(name)
        if name not in APPLICATION + ASSETS and not (rel.parent == Path(".") and name.startswith("test_") and rel.suffix == ".py"):
            raise RuntimeError("配布許可リスト外です: " + name)
        if (rel.is_absolute() or '..' in rel.parts or '\\' in name or ':' in name
                or any(x.lower() in ('data', 'logibox pdf', '.git', '__pycache__') for x in rel.parts)
                or rel.suffix.lower() not in ('.py', '.ps1', '.vbs', '.bat', '.sql', '.txt', '.md', '.ico', '.html', '.js', '.svg', '.ttf', '.pdf')):
            raise RuntimeError('配布対象外のファイルです: ' + name)
        path = source / rel
        if path.is_symlink() or not path.resolve().is_relative_to(source.resolve()) or hashlib.sha256(path.read_bytes()).hexdigest() != expected:
            raise RuntimeError('配布ファイルの照合に失敗しました: ' + name)
        result.append(rel)
    return result + [Path('SOURCE_MANIFEST.json')]


def update(target, source=SOURCE, backup_root=None):
    target, source = Path(target).resolve(), Path(source).resolve()
    if target == source or target in source.parents or source in target.parents:
        raise RuntimeError('新版は更新先と別のフォルダへ展開してください。')
    if os.environ.get('APP_DATA'):
        raise RuntimeError('APP_DATAが指定されています。対象データの取り違えを防ぐため自動更新を中止しました。管理者が保存先とバックアップを確認してください。')
    data = target / 'data'
    for path in (data, data / 'app.db', data / '.logibox-auth.lock'):
        if path.is_symlink() or (hasattr(path, 'is_junction') and path.is_junction()):
            raise RuntimeError('データ保存先にリンクがあります。変更せず中止します: ' + str(path))
    if not (data / 'app.db').is_file():
        raise RuntimeError('更新先にdata/app.dbがありません。利用中のフォルダを指定してください。新規DBは作成しません。')
    backup_root = Path(backup_root).resolve(strict=True) if backup_root else target.parent
    if not backup_root.is_dir() or backup_root == target or target in backup_root.parents:
        raise RuntimeError('バックアップ先は更新先フォルダの外を選択してください。')
    files = verified_files(source)
    # Legacy launchers also hold this lock for the server lifetime.
    with reserve_port(), data_lock(data):
        # Never overwrite a destination symlink or junction leading outside target.
        for rel in files:
            destination = target / rel
            if not destination.resolve().is_relative_to(target) or destination.is_symlink():
                raise RuntimeError('更新先に外部へのリンクがあります: ' + str(rel))
        for rel in files:
            cache = (target / rel).parent / '__pycache__'
            if not cache.resolve().is_relative_to(target):
                raise RuntimeError('外部へのキャッシュリンクがあるため更新を中止しました。')
        backup_dir = Path(tempfile.mkdtemp(prefix='LOGIBOX-before-' + VERSION + '-', dir=backup_root))
        backup = backup_dir / 'full-installation.zip'
        print('バックアップ先:', backup, flush=True)
        with zipfile.ZipFile(backup, 'w', zipfile.ZIP_DEFLATED) as archive:
            for path in sorted(target.rglob('*')):
                if path.is_symlink() or (hasattr(path, 'is_junction') and path.is_junction()):
                    raise RuntimeError('バックアップ対象にリンクがあります。変更せず中止します: ' + str(path))
                if path.is_file() and path.name != '.logibox-auth.lock':
                    archive.write(path, path.relative_to(target).as_posix())
        with zipfile.ZipFile(backup) as archive:
            if archive.testzip() is not None:
                raise RuntimeError('バックアップの照合に失敗したため更新しません。')
            # Verify the entire backup before touching application files.
            current = {path.relative_to(target).as_posix() for path in target.rglob('*')
                       if path.is_file() and path.name != '.logibox-auth.lock'}
            if current != set(archive.namelist()):
                raise RuntimeError('バックアップ中にファイル構成が変わったため更新しません。')
            for path in target.rglob('*'):
                if path.is_file() and path.name != '.logibox-auth.lock':
                    saved = archive.read(path.relative_to(target).as_posix())
                    if hashlib.sha256(saved).digest() != hashlib.sha256(path.read_bytes()).digest():
                        raise RuntimeError('バックアップ中にデータが変わったため更新しません。')
        try:
            for rel in files:
                destination = target / rel
                # Preserve all existing PDFs and user-customized document templates.
                if destination.exists() and (rel.suffix.lower() == '.pdf' or rel.parts[0] == 'document_templates'):
                    continue
                destination.parent.mkdir(parents=True, exist_ok=True)
                with tempfile.NamedTemporaryFile(dir=destination.parent, delete=False) as staged:
                    pending = Path(staged.name)
                    staged.write((source / rel).read_bytes())
                try:
                    os.replace(pending, destination)
                finally:
                    pending.unlink(missing_ok=True)
            # Invalidate only bytecode for replaced application modules, after backup.
            for rel in files:
                if rel.suffix == '.py':
                    cache = (target / rel).parent / '__pycache__'
                    for bytecode in cache.glob(rel.stem + '.*.pyc'):
                        bytecode.unlink()
        except Exception as exc:
            raise RuntimeError(f'更新未完了です。起動せずバックアップを管理者へ渡してください: {backup}') from exc
    print(f'ver.{VERSION}へ更新しました。dataは変更していません。')
    print('更新先の起動.vbsを開き、デスクトップのショートカットを更新してください。')
    return backup


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--target', help='利用中のlogiboxフォルダ（data/app.dbを含む）')
    parser.add_argument('--backup-dir', help='バックアップ保存先（更新先の外・OneDrive外を推奨）')
    parser.add_argument('--interactive', action='store_true')
    args = parser.parse_args()
    if args.interactive:
        import tkinter as tk
        from tkinter import filedialog, messagebox
        window = tk.Tk(); window.withdraw()
        selected = filedialog.askdirectory(title='利用中のlogiboxフォルダ（data/app.dbを含む）を選択')
        if not selected:
            raise SystemExit(0)
        backup_folder = filedialog.askdirectory(title='バックアップ保存先（OneDrive外のローカルフォルダを推奨）を選択', mustexist=True)
        if not backup_folder:
            raise SystemExit(0)
        try:
            backup = update(selected, backup_root=backup_folder)
        except Exception as error:
            log = diagnostic('update_failed', error, target=selected)
            messagebox.showerror('LOGIBOX 更新中止', str(error) + f'\n診断ログ: {log}'); raise SystemExit(1)
        messagebox.showinfo('LOGIBOX 更新完了',
            f'更新前バックアップ: {backup}\n\n更新先の「起動.vbs」を開いてください。\nデスクトップのアイコンも更新されます。')
    else:
        if not args.target: parser.error('--target または --interactive を指定してください。')
        try:
            update(args.target, backup_root=args.backup_dir)
        except Exception as error:
            log = diagnostic('update_failed', error, target=args.target)
            parser.exit(1, str(error) + f'\n診断ログ: {log}\n')
