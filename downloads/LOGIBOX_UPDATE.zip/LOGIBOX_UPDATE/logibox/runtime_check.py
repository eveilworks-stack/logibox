"""Local-only runtime checks. Never enumerate/kill processes or remove locks."""
from contextlib import contextmanager
import errno
import json
import os
from pathlib import Path
import socket
import tempfile
import traceback
import datetime
import urllib.request

HOST, PORT = '127.0.0.1', 8766


def diagnostic(event, error=None, **details):
    """Append diagnostics outside user data; fall back if installation is read-only."""
    record = dict(time=datetime.datetime.now().astimezone().isoformat(), event=event,
                  **details)
    if error is not None:
        record.update(error_type=type(error).__name__, error=str(error),
                      errno=getattr(error, 'errno', None), winerror=getattr(error, 'winerror', None),
                      traceback=''.join(traceback.format_exception(type(error), error, error.__traceback__)))
    for folder in (Path(__file__).resolve().parent / 'diagnostics',
                   Path(tempfile.gettempdir()) / 'LOGIBOX-diagnostics'):
        try:
            folder.mkdir(exist_ok=True)
            path = folder / 'runtime.log'
            with path.open('a', encoding='utf-8') as log:
                log.write(json.dumps(record, ensure_ascii=False) + '\n')
            return path
        except OSError:
            continue
    return None


@contextmanager
def reserve_port():
    """Exclusive bind proves availability even when local connect is filtered.

    Keep bound throughout update to exclude even old servers without a data lock.
    Never set SO_REUSEADDR: on Windows it can allow an occupied port to be bound.
    """
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as probe:
        if os.name == 'nt':
            probe.setsockopt(socket.SOL_SOCKET, socket.SO_EXCLUSIVEADDRUSE, 1)
        try:
            probe.bind((HOST, PORT))
        except OSError as error:
            log = diagnostic('port_reservation_failed', error, host=HOST, port=PORT)
            raise RuntimeError(f'ポート8766を確保できません。起動中アプリまたはWindowsのポート制限を確認してください。ログ: {log}') from error
        yield


def port_available():
    try:
        with reserve_port():
            return True
    except RuntimeError as error:
        cause = error.__cause__
        if isinstance(cause, OSError) and (cause.errno in (errno.EADDRINUSE, 10048, 10013)
                or getattr(cause, 'winerror', None) in (10048, 10013)
                or (os.name == 'nt' and cause.errno == errno.EACCES)):
            return False
        raise


def open_local(url, timeout=2):
    # Ignore HTTP_PROXY, Windows Internet Settings, PAC and redirect destinations.
    class NoRedirect(urllib.request.HTTPRedirectHandler):
        def redirect_request(self, req, fp, code, msg, headers, newurl):
            return None
    return urllib.request.build_opener(urllib.request.ProxyHandler({}), NoRedirect()).open(url, timeout=timeout)
