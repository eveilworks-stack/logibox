"""Release identity and non-destructive update regression tests."""
import hashlib
import io
import json
import os
from pathlib import Path
import sqlite3
import tempfile
import unittest
from unittest.mock import patch
import urllib.error
import zipfile
import app_version
import launcher
import update
from auth_security import data_lock


class LaunchIdentityTests(unittest.TestCase):
    def setUp(self):
        check = patch('launcher.port_available', return_value=False)
        check.start(); self.addCleanup(check.stop)

    def test_same_release_and_data_can_be_reused(self):
        with patch('launcher.open_local', return_value=io.BytesIO(json.dumps(app_version.runtime_identity()).encode())):
            self.assertTrue(launcher.ready())

    def test_old_version_other_folder_data_or_build_cannot_be_reused(self):
        for key in ('version', 'source_id', 'data_id', 'build'):
            identity = dict(app_version.runtime_identity(), **{key: 'old'})
            with self.subTest(key=key), patch('launcher.open_local', return_value=io.BytesIO(json.dumps(identity).encode())):
                with self.assertRaises(RuntimeError): launcher.ready()

    def test_legacy_server_without_runtime_is_rejected(self):
        error = urllib.error.HTTPError(launcher.URL, 404, 'missing', {}, None)
        with patch('launcher.open_local', side_effect=error):
            with self.assertRaises(RuntimeError): launcher.ready()

    def test_only_connection_refused_allows_start(self):
        with patch('launcher.open_local', side_effect=urllib.error.URLError(ConnectionRefusedError())):
            with self.assertRaises(RuntimeError): launcher.ready()
        with patch('launcher.open_local', side_effect=TimeoutError()):
            with self.assertRaises(RuntimeError): launcher.ready()


class UpdateTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory(); self.addCleanup(self.tmp.cleanup)
        self.root = Path(self.tmp.name)
        self.source, self.target = self.root / 'new', self.root / 'old'
        self.source.mkdir(); (self.target / 'data').mkdir(parents=True)
        self.env = patch.dict(os.environ, {}, clear=False)
        self.env.start(); self.addCleanup(self.env.stop); os.environ.pop('APP_DATA', None)
        self.db = self.target / 'data/app.db'
        with sqlite3.connect(self.db) as c:
            for table in ('cases', 'invoices', 'payments', 'principal', 'allocations'):
                c.execute(f'CREATE TABLE {table}(id INTEGER, amount INTEGER)')
                c.execute(f'INSERT INTO {table} VALUES(1, 2000000)')
        for name in ('files/evidence.pdf', 'documents/invoice.pdf', 'backups/old.zip'):
            path = self.target / 'data' / name
            path.parent.mkdir(exist_ok=True); path.write_bytes(b'preserve-' + name.encode())
        (self.target / 'server.py').write_text('old')
        (self.source / 'server.py').write_text('new')
        self.manifest = dict(version=app_version.VERSION, sha256={'server.py': hashlib.sha256(b'new').hexdigest()})
        self.save_manifest()

    def save_manifest(self):
        (self.source / 'SOURCE_MANIFEST.json').write_text(json.dumps(self.manifest))

    def snapshots(self):
        return {p.relative_to(self.target).as_posix():p.read_bytes() for p in (self.target / 'data').rglob('*')
                if p.is_file() and p.name != '.logibox-auth.lock'}

    def test_backup_precedes_update_and_all_data_is_unchanged(self):
        before = self.snapshots(); backup = update.update(self.target, self.source)
        self.assertEqual(before, self.snapshots())
        self.assertEqual((self.target / 'server.py').read_text(), 'new')
        with zipfile.ZipFile(backup) as z:
            self.assertEqual(z.read('server.py'), b'old')
            for path, content in before.items(): self.assertEqual(z.read(path), content)
        with sqlite3.connect(self.db) as c:
            self.assertEqual(c.execute('PRAGMA integrity_check').fetchone()[0], 'ok')
            for table in ('cases','invoices','payments','principal','allocations'):
                self.assertEqual(c.execute(f'SELECT * FROM {table}').fetchall(), [(1, 2000000)])

    def test_onedrive_japanese_path_retains_credentials_seal_pdf_and_lock(self):
        moved = self.root / 'OneDrive - 会社名' / '旧 LOGIBOX'
        moved.parent.mkdir(); self.target.rename(moved); self.target = moved
        self.db = moved / 'data/app.db'
        fixtures = {'data/company-seal.png': b'seal', 'data/login.json': b'credentials',
                    'LOGIBOX PDF/issued.pdf': b'issued',
                    'document_templates/haak_invoice.pdf': b'custom-template',
                    'data/.logibox-auth.lock': b'keep-lock'}
        for name, content in fixtures.items():
            path = moved / name; path.parent.mkdir(parents=True, exist_ok=True); path.write_bytes(content)
        template = 'document_templates/haak_invoice.pdf'
        (self.source / 'document_templates').mkdir()
        (self.source / template).write_bytes(b'distribution-template')
        self.manifest['sha256'][template] = hashlib.sha256(b'distribution-template').hexdigest()
        self.save_manifest()
        before = self.snapshots()
        local_backup = self.root / 'local-backups'; local_backup.mkdir()
        backup = update.update(moved, self.source, backup_root=local_backup)
        self.assertTrue(backup.is_relative_to(local_backup))
        self.assertEqual(before, self.snapshots())
        for name, content in fixtures.items(): self.assertEqual((moved / name).read_bytes(), content)

    def test_port_is_reserved_during_file_replacement(self):
        import runtime_check
        replace = os.replace
        def guarded_replace(*args):
            self.assertFalse(runtime_check.port_available())
            return replace(*args)
        with patch('os.replace', side_effect=guarded_replace):
            update.update(self.target, self.source)

    def test_unknown_manifest_file_cannot_overwrite_user_file(self):
        name = 'company-seal.ico'
        (self.source / name).write_bytes(b'replacement')
        (self.target / name).write_bytes(b'original')
        self.manifest['sha256'][name] = hashlib.sha256(b'replacement').hexdigest()
        self.save_manifest()
        with self.assertRaises(RuntimeError): update.update(self.target, self.source)
        self.assertEqual((self.target / name).read_bytes(), b'original')

    def test_only_replaced_module_bytecode_is_invalidated(self):
        cache=self.target/'__pycache__'; cache.mkdir()
        stale=cache/'server.cpython-312.pyc'; stale.write_bytes(b'old bytecode')
        other=cache/'unrelated.cpython-312.pyc'; other.write_bytes(b'keep')
        user_file=self.target/'data/cache.pyc'; user_file.write_bytes(b'user data')
        backup=update.update(self.target,self.source)
        self.assertFalse(stale.exists())
        self.assertEqual(other.read_bytes(),b'keep')
        self.assertEqual(user_file.read_bytes(),b'user data')
        with zipfile.ZipFile(backup) as z:
            self.assertEqual(z.read('__pycache__/server.cpython-312.pyc'),b'old bytecode')

    def test_running_server_lock_prevents_changes(self):
        with data_lock(self.target / 'data'):
            with self.assertRaises(RuntimeError): update.update(self.target, self.source)
        self.assertEqual((self.target / 'server.py').read_text(), 'old')

    def test_missing_database_never_creates_one(self):
        self.db.unlink()
        with self.assertRaises(RuntimeError): update.update(self.target, self.source)
        self.assertFalse(self.db.exists())

    def test_bad_hash_or_data_entry_aborts_before_update(self):
        for name in ('server.py','data/app.db','../outside.py'):
            self.manifest['sha256'] = {name:'invalid'}; self.save_manifest()
            with self.assertRaises(RuntimeError): update.update(self.target,self.source)
        self.assertEqual((self.target / 'server.py').read_text(), 'old')

    def test_backup_failure_prevents_update(self):
        with patch('zipfile.ZipFile.testzip', return_value='broken'):
            with self.assertRaises(RuntimeError): update.update(self.target,self.source)
        self.assertEqual((self.target / 'server.py').read_text(), 'old')


if __name__ == '__main__': unittest.main()
