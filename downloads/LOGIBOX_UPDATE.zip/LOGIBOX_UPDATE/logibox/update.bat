@echo off
setlocal
cd /d "%~dp0"
set "PYTHONIOENCODING=utf-8"
if not exist diagnostics mkdir diagnostics
set "PYTHON=py"
py -c "import sys; sys.exit(sys.version_info < (3,10))" >nul 2>nul
if not errorlevel 1 goto run
set "PYTHON=python"
python -c "import sys; sys.exit(sys.version_info < (3,10))" >nul 2>nul
if errorlevel 1 goto error
:run
if "%~1"=="" (
  %PYTHON% update.py --interactive
) else (
  %PYTHON% update.py %*
)
set "RESULT=%ERRORLEVEL%"
if "%~1"=="" if not "%RESULT%"=="0" pause
exit /b %RESULT%
:error
echo Python 3.10+ is required.
echo Python 3.10+ not found on PATH.>diagnostics\bootstrap.log
pause
exit /b 1
