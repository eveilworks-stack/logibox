function fundingPanel(cid,slot,s,data){
 const mode=s?.funding_method||'cash', incoming=data?.incoming||[], sum=incoming.reduce((n,x)=>n+x.carry_over,0)+(data?.ledger_incoming||[]).reduce((n,x)=>n+x.amount,0);
 const release=data?.release, balance=data?.balance, account=balance?.account;
 return `<div style="grid-column:1/-1" id="funding-${slot}">
 <label class="f">元金の入金・充当方法<select id="s${slot}_funding" onchange="toggleFunding(${slot})">
 ${[['cash','新規現金入金'],['carry','他案件・一時預かり金から充当'],['mixed','併用']].map(([key,label])=>`<option value="${key}" ${key===mode?'selected':''}>${label}</option>`).join('')}</select></label>
 ${cashPanel(slot,s,data,mode)}
 <p>充当先：${esc(CUR.v.case.case_no||'案件番号未登録')} ${esc(CUR.v.case.name)}</p>
 <div id="funding-input-${slot}" ${mode==='cash'?'hidden':''}>
 <p class="m">同じ下請けの、ハークから回収確認済みの未使用元金がある案件を選択してください。複数案件・一部金額に対応します。</p>
 <div id="funding-entries-${slot}"></div><button class="s" type="button" onclick="addFundingEntry(${slot})">充当元を追加</button>
 ${((data?.principal_sources||data?.sources||[]).length+(data?.custody||[]).filter(x=>x.balance>0&&x.case_id!==cid).length)?'':`<p class="m">追加可能な充当元がありません。${incoming.length?'登録済みの充当元は「編集・取消」で金額を調整できます。':'充当元案件のハーク実入金・元金回収確認を確認してください。'}</p>`}</div>
 <div id="funding-totals-${slot}" aria-live="polite">${fundingBreakdown(s?.principal_tax_in||0,data?.cash_received||0,sum,(data?.ledger_incoming||[]).filter(x=>x.kind==='hold').reduce((n,x)=>n+x.amount,0))}</div>
 ${(data?.unavailable||[]).length?`<details><summary>充当対象外の案件と理由</summary>${data.unavailable.map(x=>`<p>${esc(x.case_no||'案件番号未登録')} ${esc(x.name)}：${esc(x.reason)}</p>`).join('')}</details>`:''}
 ${ledgerPanel(cid,slot,s,data)}
 ${incoming.map(x=>`<section class="card"><b>${esc(x.case_no||'案件番号未登録')} ${esc(x.name)}</b><p>${Y(x.carry_over)} ／ 承諾日 ${esc(x.consent_date||'―')} ／ ${esc(x.consent_method||'未登録')}</p><p>${esc(x.consent_record||'')}</p><p class="m">充当確定日 ${esc(x.carry_confirmed_date||'旧記録：未登録')} ／ 作成 ${esc(x.carry_created_at||'旧記録：未登録')}</p><button class="s" type="button" onclick="editFunding(${cid},${slot},${x.settlement_id},${x.id})">編集・取消</button><div id="funding-edit-${x.id}"></div>${carryHistoryBlock(x)}</section>`).join('')}
 ${(data?.history||[]).length?`<details><summary>元金充当履歴（取消・付替えを含む）</summary>${data.history.map(h=>`<p><b>${esc(new Date(h.changed_at).toLocaleString('ja-JP'))}</b> ${esc(h.reason)}</p><p>変更前：${esc(fundingHistoryLabel(h.before))}</p><p>変更後：${esc(fundingHistoryLabel(h.after))}</p>`).join('')}</details>`:''}
 ${s?`<details><summary>ハークからの元金回収・個別返金の確認</summary><p class="m">回収額は利益を除いた、この下請けに帰属する元金のみです。一部入金ではハーク画面に実入金累計額を保存してから登録してください。返金累計は月次精算以外で既に返金した元金です。取消・訂正は累計額を修正し、理由を残します。</p>
 ${row('元金残高',Y(balance?.balance||0))}${row('うち充当可能額',Y(balance?.available||0))}
 ${fld('回収確認済み元金累計（円）',`s${slot}_recovered`,balance?.recovered||0,{num:1})}${fld('個別返金済み元金累計（円）',`s${slot}_refunded`,balance?.refunded||0,{num:1})}${fld('確認・返金日',`s${slot}_account_date`,account?.record_date||new Date().toLocaleDateString('sv-SE'),{type:'date'})}${fld('確認記録・変更理由',`s${slot}_account_note`,'')}
 <button class="s" type="button" onclick="savePrincipalAccount(${cid},${slot},${account?.revision||0})">回収・返金を保存</button>
 ${(data?.account_history||[]).map(h=>{const a=JSON.parse(h.after_json);return `<p>${esc(new Date(h.changed_at).toLocaleString('ja-JP'))} ／ ${esc(a.record_date)} ／ 回収 ${Y(a.recovered)} ／ 返金 ${Y(a.refunded)} ／ ${esc(a.note)}</p>`}).join('')}</details>
 <details><summary>充当額の任意上限（既存の確認記録）</summary><p class="m">ハークから回収確認済みの元金に、追加の上限を設定できます。未回収元金は指定しても充当できません。</p>
 ${fld('充当へ回せる確認済額（円）',`s${slot}_release`,release?.amount||0,{num:1})}${fld('残高の確認記録',`s${slot}_release_record`,release?.record||'')}
 ${row('この案件からの充当済額',Y(data?.source_allocated||0))}${row('この案件の確認済残高（登録済明細は編集で調整）',Y(data?.source_remaining||0))}
 <button class="s" type="button" onclick="savePrincipalRelease(${cid},${slot},${release?.revision||0})">確認済額を保存</button></details>`:'<p class="m">充当元としての残高確認は下請けを保存後に登録できます。</p>'}
 </div>`;
}
function savePrincipalAccount(cid,slot,revision){act(async()=>{await api('PUT',`/api/cases/${cid}/subs/${slot}/principal-account`,{recovered:G(`s${slot}_recovered`),refunded:G(`s${slot}_refunded`),record_date:G(`s${slot}_account_date`),note:G(`s${slot}_account_note`),expected_revision:revision});await rf()},'回収・返金を保存しました');}
function fundingBreakdown(principal,cash,carry,held=0){return row('担当元金',Y(principal))+row('新規入金済額',Y(cash))+row('他案件からの充当済額',Y(carry-held))+row('一時預かり金からの充当済額',Y(held))+row('充当済額合計',Y(carry))+row('未充足額',Y(Math.max(0,principal-cash-carry)));}
function cashPanel(slot,s,data,mode){return `<section class="card" id="funding-cash-${slot}" data-request-key="${crypto.randomUUID()}" ${mode==='carry'?'hidden':''}><b>新規入金（未保存の追加入力）</b><div class="g">
 <label class="f">入金方法<select id="s${slot}_cash_method" onchange="document.getElementById('cash-hand-${slot}').hidden=this.value!=='hand'"><option value="bank">銀行振込</option><option value="hand">手渡し</option></select></label>
 ${fld('今回の入金金額（円）',`s${slot}_cash_amount`,'',{num:1})}${fld('入金日',`s${slot}_cash_date`,'',{type:'date'})}${fld('入金記録',`s${slot}_cash_note`,'')}
 </div><div id="cash-hand-${slot}" hidden><label><input type="checkbox" id="s${slot}_receipt">領収書を確認</label><label><input type="checkbox" id="s${slot}_stamp">収入印紙の要否・貼付を確認</label></div>
 <p class="m">金額を入力した場合だけ、新しい入金履歴を追加します。下請けの保存で確定します。</p></section>
 <details><summary>保存済み入金履歴</summary>${(data?.cash_history||[]).map(x=>`<p>${esc(x.received_on)} ／ ${x.method==='hand'?'手渡し':'銀行振込'} ／ ${Y(x.amount)} ／ ${esc(x.note)} ${x.method==='hand'?'／ 領収書・印紙確認済み':''}</p>`).join('')}${s?.principal_received_date?`<p>旧入金記録：${esc(s.principal_received_date)}（金額別台帳追加前）</p>`:''}</details>`;}
function consentInputs(prefix){return `${fld('承諾日',prefix+'_date','',{type:'date'})}${fld('承諾方法',prefix+'_method','')}${fld('承諾記録',prefix+'_record','')}`;}
function consentValues(prefix){return {consent_date:G(prefix+'_date'),consent_method:G(prefix+'_method'),consent_record:G(prefix+'_record')};}
function ledgerPanel(cid,slot,s,data){
 const labels={created:'預かり発生',principal:'他案件元金充当',hold:'預かり金充当',refund:'返金',cancel:'充当取消'};
 const format=x=>`<p>${esc(labels[x.kind])} ／ ${esc(x.case_no||'案件番号未登録')} ${esc(x.name)} → ${esc(x.target_case_no||'―')} ${esc(x.target_name||'')} ／ ${Y(x.amount)} ／ 確定 ${esc(x.event_date)} ／ 承諾 ${esc(x.consent_date)} ${esc(x.consent_method)} ${esc(x.consent_record)} ／ ${esc(x.note)} ${x.cancelled?'（取消済み）':''}</p>`;
 return `<details><summary>保存済み元金充当・預かり金履歴</summary>${(data?.ledger_history||[]).map(x=>`${format(x)}${['principal','hold'].includes(x.kind)&&!x.cancelled?`<button type="button" class="s" onclick="openLedgerCancel(${x.id},${slot})">訂正・取消</button><div id="ledger-cancel-${slot}-${x.id}"></div>`:''}`).join('')||'<p>履歴はありません</p>'}</details>
 <details><summary>一時預かり金台帳（同一下請け）</summary><a href="/api/export/funding">元金・預かり金履歴CSV</a>${(data?.custody||[]).map(f=>`<section class="card"><b>#${f.id} ${esc(f.case_no||'案件番号未登録')} ${esc(f.name)}</b><p>${esc(f.sub_name)} ／ ${esc(f.reason)} ／ 発生 ${esc(f.occurred_on)}</p>${row('当初金額',Y(f.amount))}${row('残高',Y(f.balance))}${row('充当済',Y(f.allocated))}${row('返金済',Y(f.refunded))}<details><summary>発生・充当・返金履歴</summary>${f.history.map(format).join('')}</details>${f.balance?`<button type="button" class="s" onclick="openCustodyRefund(${f.id},${slot})">返金を記録</button><div id="custody-refund-${slot}-${f.id}"></div>`:''}</section>`).join('')||'<p>台帳登録はありません</p>'}</details>
 ${s?`<details><summary>この元金を一時預かり金へ振替・既存預かり金を台帳へ登録</summary><p class="m">実入金・回収確認済みの元金を振り替えます。発生理由と下請けの承諾を記録してください。台帳登録後はこの台帳から充当・返金します。</p><div class="g">${fld('預かり金額（円）',`hold_${slot}_amount`,'',{num:1})}${fld('発生日',`hold_${slot}_occurred`,'',{type:'date'})}${fld('発生理由',`hold_${slot}_reason`,'')}${consentInputs('hold_'+slot)}</div><button type="button" class="s" onclick="createCustody(${cid},${slot})">預かり金台帳へ登録</button></details>`:''}`;
}
function createCustody(cid,slot){act(async()=>{await api('POST',`/api/cases/${cid}/subs/${slot}/custody`,{amount:G(`hold_${slot}_amount`),occurred_on:G(`hold_${slot}_occurred`),reason:G(`hold_${slot}_reason`),...consentValues('hold_'+slot)});await rf()},'一時預かり金を登録しました');}
function openCustodyRefund(id,slot){document.getElementById(`custody-refund-${slot}-${id}`).dataset.requestKey=crypto.randomUUID();const p=`refund_${slot}_${id}`;document.getElementById(`custody-refund-${slot}-${id}`).innerHTML=`<div class="g">${fld('返金額（円）',p+'_amount','',{num:1})}${fld('返金日',p+'_event','',{type:'date'})}${fld('返金先・振込記録',p+'_note','')}${consentInputs(p)}</div><button type="button" class="s" onclick="saveCustodyRefund(${id},${slot})">返金履歴を保存</button>`;}
function saveCustodyRefund(id,slot){const p=`refund_${slot}_${id}`;act(async()=>{await api('POST',`/api/custody/${id}/refund`,{amount:G(p+'_amount'),event_date:G(p+'_event'),note:G(p+'_note'),request_key:document.getElementById(`custody-refund-${slot}-${id}`).dataset.requestKey,...consentValues(p)});await rf()},'返金履歴を保存しました');}
function openLedgerCancel(id,slot){const p=`cancel_${slot}_${id}`;document.getElementById(`ledger-cancel-${slot}-${id}`).innerHTML=`<p>訂正は取消後に正しい内容を追加してください。元の履歴は残ります。</p><div class="g">${fld('取消理由',p+'_note','')}${consentInputs(p)}</div><button type="button" class="s" onclick="cancelLedger(${id},${slot})">充当を取り消す</button>`;}
function cancelLedger(id,slot){const p=`cancel_${slot}_${id}`;act(async()=>{await api('POST',`/api/funding-events/${id}/cancel`,{note:G(p+'_note'),...consentValues(p)});await rf()},'充当を取り消しました');}
function fundingHistoryLabel(x){return `${x.source_case_no||'案件番号未登録'} ${x.source_name||''} → ${x.carry_over?(x.target_case_no||'案件番号未登録'):'充当なし'} ${x.target_name||''} ／ ${Y(x.carry_over)} ／ 承諾日 ${x.consent_date||'―'} ／ ${x.consent_method||'未登録'} ／ ${x.consent_record||'―'}`;}
function toggleFunding(slot){const mode=G(`s${slot}_funding`);document.getElementById(`funding-input-${slot}`).hidden=mode==='cash';document.getElementById(`funding-cash-${slot}`).hidden=mode==='carry';}
const fundingRefreshRequests={};
async function refreshFunding(cid,slot){
 const request=(fundingRefreshRequests[slot]||0)+1;fundingRefreshRequests[slot]=request;
 const sid=G(`s${slot}_id`); if(!sid){CUR.funding[slot]={};document.getElementById(`funding-${slot}`).outerHTML=fundingPanel(cid,slot,null,{});return;}
 act(async()=>{const data=await api('GET',`/api/cases/${cid}/funding-options?sub_id=${encodeURIComponent(sid)}`);if(CUR.v?.case.id!==cid||fundingRefreshRequests[slot]!==request||G(`s${slot}_id`)!==sid)return;CUR.funding[slot]=data;
 const s=CUR.v.subs.find(x=>x.slot===slot&&String(x.sub_id)===sid);
 document.getElementById(`funding-${slot}`).outerHTML=fundingPanel(cid,slot,s,data);fundingTotals(slot);});
}
function addFundingEntry(slot){
 const sources=CUR.funding[slot]?.principal_sources||CUR.funding[slot]?.sources||[], holds=(CUR.funding[slot]?.custody||[]).filter(x=>x.case_id!==CUR.v.case.id&&x.balance>0);
 const list=document.getElementById(`funding-entries-${slot}`);
 const box=document.createElement('div');box.className='card funding-entry';
 box.dataset.requestKey=crypto.randomUUID();
 box.innerHTML=`<b>未保存の充当入力</b><div class="g"><label class="f">充当元<select name="source_id" onchange="updateFundingBalance(this,${slot})"><option value="">選択してください</option><optgroup label="他案件の充当可能元金">${sources.map(x=>`<option value="principal:${x.case_id}" data-balance="${x.available}">${esc(x.case_no||'案件番号未登録')} ${esc(x.name)} ／ ${Y(x.available)}</option>`).join('')}</optgroup><optgroup label="一時預かり金">${holds.map(x=>`<option value="hold:${x.id}" data-balance="${x.balance}">${esc(x.case_no||'案件番号未登録')} ${esc(x.name)} ／ ${esc(x.reason)} ／ ${Y(x.balance)}</option>`).join('')}</optgroup></select></label><p class="funding-balance" aria-live="polite">充当可能残高：―</p>
 <label class="f">今回の充当額（円）<input name="carry_over" inputmode="numeric" oninput="fundingTotals(${slot})" required></label>
 <label class="f">承諾日<input type="date" name="consent_date" required></label><label class="f">承諾方法<input name="consent_method" maxlength="80" placeholder="LINE・メール・書面など" required></label><label class="f">承諾記録<input name="consent_record" maxlength="500" placeholder="承諾者・メッセージの日時など" required></label></div><button class="s" type="button">この入力を外す</button>`;
 box.querySelector('button').onclick=()=>{box.remove();fundingTotals(slot)};list.append(box);
}
function updateFundingBalance(select,slot){select.closest('.funding-entry').querySelector('.funding-balance').textContent='充当可能残高：'+Y(Number(select.selectedOptions[0]?.dataset.balance||0));fundingTotals(slot);}
function fundingTotals(slot){
 const data=CUR.funding[slot];
 const registered=(data?.incoming||[]).reduce((n,x)=>n+x.carry_over,0)+(data?.ledger_incoming||[]).reduce((n,x)=>n+x.amount,0);
 const pending=[...document.querySelectorAll(`#funding-entries-${slot} [name=carry_over]`)].reduce((n,x)=>n+Number(x.value.replaceAll(',','')||0),0);
 document.getElementById(`funding-totals-${slot}`).innerHTML=fundingBreakdown(Number(G(`s${slot}_pr`).replaceAll(',','')),data?.cash_received||0,registered,(data?.ledger_incoming||[]).filter(x=>x.kind==='hold').reduce((n,x)=>n+x.amount,0))+row('未保存の充当入力額',Y(pending));
}
function fundingValues(slot){
 const funding_method=G(`s${slot}_funding`);
 const allocations=funding_method==='cash'?[]:[...document.querySelectorAll(`#funding-entries-${slot} .funding-entry`)].map(box=>{
  for(const input of box.querySelectorAll('input,select')){if(!input.value.trim())throw new Error('充当元・金額・承諾日・承諾方法・承諾記録を入力してください');}
  const values=Object.fromEntries([...box.querySelectorAll('[name]')].map(x=>[x.name,x.value]));
  const [source_type,source_id]=values.source_id.split(':');return {...values,source_type,source_id,request_key:box.dataset.requestKey};
 });
 const amount=G(`s${slot}_cash_amount`);
 const cash_entry=funding_method!=='carry'&&amount?{amount,received_on:G(`s${slot}_cash_date`),method:G(`s${slot}_cash_method`),receipt_checked:document.getElementById(`s${slot}_receipt`).checked,stamp_checked:document.getElementById(`s${slot}_stamp`).checked,note:G(`s${slot}_cash_note`),request_key:document.getElementById(`funding-cash-${slot}`).dataset.requestKey}:null;
 return {funding_method,allocations,cash_entry};
}
function savePrincipalRelease(cid,slot,revision){act(async()=>{await api('PUT',`/api/cases/${cid}/subs/${slot}/principal-release`,{amount:G(`s${slot}_release`),record:G(`s${slot}_release_record`),expected_revision:revision});await rf()},'確認済額を保存しました');}
function editFunding(cid,slot,id,lineId){act(async()=>{
 const period=CUR.funding[slot].incoming.find(x=>x.id===lineId).period;
 const monthlyData=await api('GET',`/api/monthly?period=${encodeURIComponent(period)}`);
 const s=monthlyData.settlements.find(x=>x.id===id),line=s.lines.find(x=>x.id===lineId);
 const host=document.getElementById(`funding-edit-${lineId}`);
 host.innerHTML=`<form><div class="g"><label class="f">充当先案件<select name="target_id" onchange="changeCarryTarget(this)"><option value="">案件を選択</option><option value="hold" ${line.temporary_hold?'selected':''}>一時預かり（充当先を解除）</option>${s.targets.filter(x=>x.id!==line.case_id&&x.due_date>line.due_date).map(x=>`<option value="${x.id}" ${x.id===line.carry_to_case_id?'selected':''}>${esc(x.case_no||'案件番号未登録')} ${esc(x.name)}</option>`).join('')}</select></label><label class="f">充当・一時預かり額（円、0円で解除・返金）<input name="carry_over" value="${line.carry_over}" ${s.status==='paid'?'readonly':''} required></label><label class="f">承諾日<input type="date" name="consent_date" value="${esc(line.consent_date||'')}"></label><label class="f">承諾方法<input name="consent_method" maxlength="80" value="${esc(line.consent_method||'')}"></label><label class="f">承諾記録<input name="consent_record" maxlength="500" value="${esc(line.consent_record||'')}"></label><label class="f">変更理由<input name="change_reason" maxlength="500" required></label></div><p class="m">一時預かりはLINEで了承を得てから承諾日を入力してください。承諾記録は任意です。了承依頼文は月次精算の明細から作成できます。支払済みの金額変更や、後続記録と矛盾する変更はできません。</p><button>充当・一時預かりを保存</button></form>`;
 host.querySelector('form').onsubmit=event=>{event.preventDefault();const values=Object.fromEntries(new FormData(event.currentTarget));act(async()=>{await api('PUT',`/api/settlements/${id}/lines/${lineId}`,{...values,expected_revision:line.carry_revision});await rf()},'充当を更新しました');};
 });}
