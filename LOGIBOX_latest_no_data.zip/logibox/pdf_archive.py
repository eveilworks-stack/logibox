"""Readable PDF copies; original application evidence is never moved or deleted."""
import hashlib
import os
from pathlib import Path
import re
import tempfile
import threading

LOCK = threading.Lock()
LABELS = {'principal_invoice': '元金請求書', 'haak_invoice': 'ハーク請求書', 'receipt': '領収書'}


def safe(value):
    return re.sub(r'[<>:"/\\|?*\x00-\x1f]', '＿', str(value)).strip(' .')[:60] or '未設定'


def day(value):
    parts = str(value or '').split('-')
    month = parts[1] if len(parts) > 1 and parts[1].isdigit() and 1 <= int(parts[1]) <= 12 else '××'
    date = parts[2] if len(parts) > 2 and parts[2].isdigit() and 1 <= int(parts[2]) <= 31 else '××'
    return f'{month.zfill(2)}／{date.zfill(2)}'


def case_name(row):
    return f"{safe(row['case_no'] or 'SP00000')},{day(row['start_date'])}-{day(row['due_date'])},{safe(row['mgmt_no'])}"


def sync(c, files, docs, root):
    root = Path(root)
    with LOCK:
        root.mkdir(parents=True, exist_ok=True)
        copied = 0
        cases = {r['id']: r for r in c.execute('SELECT * FROM cases')}

        def label(date, amount, partner, kind):
            # 日付・金額・取引先はWindowsのファイル検索でも探せるよう先頭に置く。
            return f"{date or '日付未登録'}_{amount if amount is not None else '金額未登録'}円_{safe(partner or '取引先未登録')[:20]}_{kind}"

        def copy(cid, folder, stored, kind, label):
            nonlocal copied
            if not stored:
                return
            if cid not in cases or Path(stored).name != stored:
                raise ValueError('PDFの保存先情報を確認してください')
            source = Path(folder) / stored
            if source.suffix.lower() != '.pdf':
                return
            prefix = case_name(cases[cid])
            target_dir = root / prefix / kind
            target_dir.mkdir(parents=True, exist_ok=True)
            raw = source.read_bytes()
            digest = hashlib.sha256(raw).hexdigest()[:12]
            target = target_dir / f'{prefix}_{safe(label)}_{digest}.pdf'
            if target.exists():
                if target.read_bytes() != raw:
                    raise ValueError(f'保存済みコピーの内容が異なります: {target.name}')
                return
            fd, temporary = tempfile.mkstemp(dir=target_dir, suffix='.tmp')
            try:
                with os.fdopen(fd, 'wb') as out:
                    out.write(raw)
                os.replace(temporary, target)
            finally:
                if os.path.exists(temporary):
                    os.remove(temporary)
            copied += 1

        for r in c.execute("""SELECT a.*,p.invoice_date,p.amount_tax_in,s.name AS partner FROM attachments a
                              LEFT JOIN purchases p ON p.id=a.purchase_id LEFT JOIN suppliers s ON s.id=p.supplier_id
                              WHERE a.mime='application/pdf'"""):
            copy(r['case_id'], files, r['stored_name'], '読込PDF',
                 label(r['invoice_date'], r['amount_tax_in'], r['partner'], f"添付{r['id']}"))
        for r in c.execute("SELECT ar.*,a.case_id FROM attachment_revisions ar JOIN attachments a ON a.id=ar.attachment_id WHERE ar.mime='application/pdf'"):
            copy(r['case_id'], files, r['stored_name'], '読込PDF', f"添付{r['attachment_id']}_旧版{r['id']}")
        for r in c.execute('SELECT d.*,sc.name AS partner FROM issued_documents d LEFT JOIN subcontractors sc ON sc.id=d.sub_id'):
            copy(r['case_id'], docs, r['file'], '発行PDF',
                 label(r['issued_date'], r['amount_tax_in'], r['partner'] or 'ハーク',
                       f"{LABELS.get(r['doc_type'], '帳票')}{r['id']}_第{r['revision']}版"))
        for r in c.execute('SELECT h.*,d.case_id,d.doc_type FROM issued_document_history h JOIN issued_documents d ON d.id=h.doc_id'):
            copy(r['case_id'], docs, r['file'], '発行PDF', f"{LABELS.get(r['doc_type'], '帳票')}{r['doc_id']}_第{r['revision']}版")
        for r in c.execute('''SELECT DISTINCT i.*,l.case_id,sc.name AS partner FROM sub_invoices i
                              JOIN settlement_lines l ON l.settlement_id=i.settlement_id
                              JOIN settlements s ON s.id=i.settlement_id JOIN subcontractors sc ON sc.id=s.sub_id'''):
            copy(r['case_id'], docs, r['file'], '読込PDF',
                 label(r['received_date'], r['amount_tax_in'], r['partner'], f"下請け受領請求書{r['id']}"))
        return copied
